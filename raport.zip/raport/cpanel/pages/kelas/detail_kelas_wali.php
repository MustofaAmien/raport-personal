<?php
include "../lib/inc.session.php";
?>

<!DOCTYPE html>
<html>

<link rel="stylesheet" href="../cpanel/plugins/iCheck/flat/blue.css">

<body class="hold-transition skin-blue sidebar-mini">

    <!-- Main content -->
    <section class="content">

        <div class="row">
            <div class="col-md-12">
                <!-- USERS LIST -->
                <div class="box box-danger">
                    <div class="box-header with-border">
                        <?php
                        $ex = mysqli_query($connect, "SELECT * FROM `kelas`, `guru` WHERE kelas.wali_kelas = guru.nik AND guru.nik = '$_GET[tid]'");
                        $x = mysqli_fetch_array($ex);
                        if ($x) {
                            ?>
                            <h3 class="box-title"><?php echo $x['nama_kelas']; ?></h3>
                            <small><?php echo $x['nama_guru']; ?></small>
                        <?php } else { ?>
                            <h3 class="box-title">Nama Kelas Tidak Tersedia</h3>
                        <?php } ?>
                        <div class="box-tools pull-right">
                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                        </div>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body no-padding">

                        <ul class="users-list clearfix">
                            <?php
                            if ($x) {
                                $ed = mysqli_query($connect, "SELECT * FROM siswa, kelas, guru WHERE siswa.kelas = kelas.id_kelas AND kelas.id_kelas = '{$x['id_kelas']}' AND kelas.wali_kelas = guru.nik AND guru.nik = '$_GET[tid]'");
                                while ($r = mysqli_fetch_array($ed)) {
                                    ?>
                                    <li>
                                        <?php if ($r['img_pengguna'] == "") { ?>
                                            <img src='img_user/small_default.jpg' alt="User Image">
                                        <?php } else { ?>
                                            <img src="img_user/small_<?php echo $r['img_pengguna']; ?>" alt="User Image">
                                        <?php } ?>
                                        <br>
                                        <br>
                                        <b><?php echo $r['nama_siswa']; ?></b>
                                    </li>
                                <?php }
                            } else {
                                echo "Data Siswa Tidak Tersedia";
                            } ?>
                        </ul>

                        <!-- /.users-list -->
                    </div>
                    <!-- /.box-body -->
                    <div class="box-footer text-center">
                    </div>
                    <!-- /.box-footer -->
                </div>
                <!--/.box -->
            </div>
            <div class="col-md-12">
                <!-- Custom Tabs -->
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#tab_1" data-toggle="tab">Siswa</a></li>
                        <!-- Add other tabs here -->
                    </ul>
                    <div class="tab-content">
                        <div class="tab-pane active" id="tab_1">
                            <div class="box">
                                <div class="box-body">
                                    <table id="example1" class="table table-bordered table-striped">
                                        <thead>
                                            <tr>
                                                <th>No</th>
                                                <th>Nama Siswa</th>
                                                <th></th>
                                                <th></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if ($x) {
                                                $vwj = mysqli_query($connect, "SELECT DISTINCT * FROM siswa, guru, kelas WHERE EXISTS (SELECT * FROM nilai WHERE nilai.id_siswa = siswa.nis) AND siswa.kelas = kelas.id_kelas AND kelas.id_kelas = '{$x['id_kelas']}' AND kelas.wali_kelas = guru.nik AND guru.nik = '$_GET[tid]'");
                                                $no = 1;
                                                while ($l = mysqli_fetch_array($vwj)) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $no; ?></td>
                                                        <td><?php echo $l['nama_siswa']; ?></td>
                                                        <td>
                                                            <form action="pages/nilai/pdf_nilai.php" method="post" name="postform">
                                                                <input type="hidden" name="tid" value="<?php echo $l['nis']; ?>">
                                                                <input type="submit" class="btn btn-block btn-primary" name="getPdf" value="Cetak">
                                                            </form>
                                                        </td>
                                                        <td>
                                                            <input type="button" class="btn btn-block btn-danger" name="Lihat" value="Lihat" onclick="window.location='?page=vwRpSw&tid=<?php echo $l['nis']; ?>' ">
                                                        </td>
                                                    </tr>
                                            <?php
                                                    $no++;
                                                }
                                            } else {
                                                echo "Data Siswa Tidak Tersedia";
                                            } ?>
                                        </tbody>
                                    </table>
                                </div><!-- /.box-body -->
                            </div><!-- /.box -->
                        </div>
                        <!-- Add other tab content here -->
                    </div>
                </div>
                <!-- nav-tabs-custom -->
            </div>
        </div>
        <!-- /.box-header -->

    </section>

    <!-- script datatables -->
    <script>
        $(function () {
            $("#example1").DataTable();
        });
    </script>

</body>

</html>
