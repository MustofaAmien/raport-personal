<?php include "../lib/inc.session.php"; ?>

<!DOCTYPE html>
<html>
<body>

<h2>Form Tambah Siswa</h2>

<form action="proses_tambah_siswa.php" method="post">
  <label for="nama_siswa">Nama Siswa:</label>
  <input type="text" name="nama_siswa" required><br>

  <label for="kelas">Kelas:</label>
  <select name="kelas" required>
    <!-- Tampilkan daftar kelas dari database -->
    <?php
    $result = mysqli_query($connect, "SELECT * FROM kelas");
    while ($row = mysqli_fetch_array($result)) {
      echo "<option value='{$row['id_kelas']}'>{$row['nama_kelas']}</option>";
    }
    ?>
  </select><br>

  <input type="submit" value="Tambah Siswa">
</form>

</body>
</html>
