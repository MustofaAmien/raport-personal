<?php
include "../lib/inc.session.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama_guru = $_POST["nama_guru"];

  // Tambahkan variabel lainnya sesuai kebutuhan

  $query = "INSERT INTO guru (nama_guru) VALUES ('$nama_guru')";

  if (mysqli_query($connect, $query)) {
    echo "Guru berhasil ditambahkan.";
  } else {
    echo "Error: " . $query . "<br>" . mysqli_error($connect);
  }
}
?>
