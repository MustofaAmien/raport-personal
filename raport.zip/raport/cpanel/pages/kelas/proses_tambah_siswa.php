<?php
include "../lib/inc.session.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  $nama_siswa = $_POST["nama_siswa"];
  $kelas_id = $_POST["kelas"];

  $query = "INSERT INTO siswa (nama_siswa, kelas) VALUES ('$nama_siswa', '$kelas_id')";

  if (mysqli_query($connect, $query)) {
    echo "Siswa berhasil ditambahkan.";
  } else {
    echo "Error: " . $query . "<br>" . mysqli_error($connect);
  }
}
?>
