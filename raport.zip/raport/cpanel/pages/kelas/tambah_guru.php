<?php include "../lib/inc.session.php"; ?>

<!DOCTYPE html>
<html>
<body>

<h2>Form Tambah Guru</h2>

<form action="proses_tambah_guru.php" method="post">
  <label for="nama_guru">Nama Guru:</label>
  <input type="text" name="nama_guru" required><br>

  <!-- Tambahkan input lainnya sesuai kebutuhan (contoh: NIK, dll.) -->

  <input type="submit" value="Tambah Guru">
</form>

</body>
</html>
