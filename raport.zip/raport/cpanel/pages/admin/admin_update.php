<?php
include "../conf/koneksi.php";
include "../conf/fungsi_thumb.php";
include "../lib/inc.session.php";

if (isset($_POST['submit'])) {
    $errors = [];

    function antiinjection($data)
    {
        global $connect;
        $filter_sql = mysqli_real_escape_string($connect, $data);
        return $filter_sql;
    }

    $no_induk = antiinjection($_POST['no_induk']);
    $nama = antiinjection($_POST['nama']);
    $email = antiinjection($_POST['email']);
    $username = antiinjection($_POST['username']);
    $password = antiinjection($_POST['password']);
    $tempat_lahir = antiinjection($_POST['tempat_lahir']);
    $tgl_lahir = antiinjection($_POST['tgl_lahir']);
    $jk = antiinjection($_POST['jk']);
    $agama = antiinjection($_POST['agama']);
    $alamat = antiinjection($_POST['alamat']);
    $no_telp = antiinjection($_POST['no_telp']);
    $hak_akses = antiinjection($_POST['hak_akses']);

    $salt = 'indikost';
    $hashed_password = md5($salt . $password);

    $query = "SELECT * FROM pengguna WHERE username = '" . $_SESSION['username'] . "' AND idu = '$no_induk'";

    // Debugging: print the query
    // echo "Debug: Query: $query <br>";

    $result = mysqli_query($connect, $query);

    if ($result) {
        $userData = mysqli_fetch_array($result);

        // Debugging: print values
echo "Debug: Session Username: $_SESSION[username], No Induk: $no_induk <br>";
echo "Debug: UserData Username: $userData[username], Hak Akses: $userData[hak_akses] <br>";

if ($userData && isset($_SESSION['username']) && isset($userData['username']) && isset($userData['hak_akses'])) {
    if (strtolower($_SESSION['username']) == strtolower($userData['username']) && strtolower($userData['hak_akses']) == 'admin') {
        // Existing code for admin...
        $updateQuery = "UPDATE `pengguna` SET
            `idu`='$no_induk',
            `nama`='$nama',
            `email`='$email',
            `username`='$username',
            `password`='$hashed_password',
            `hak_akses`='$hak_akses'
        WHERE idu = '$no_induk'";
        
        // Rest of the code...
    } else {
        echo "User is not an admin.";
    }
} else {
    echo "User data is not set or incomplete.";
}


                mysqli_query($connect, $updateQuery);

                // Additional update for admin table...
                // ...

                echo "<script>alert('Data pengguna sudah diupdate.');</script>";
                echo "<meta http-equiv='refresh' content='0;url=?page=vwUs'>";
            } else {
                echo "Data pengguna tidak sesuai dengan kriteria atau bukan admin.";
            }
        } else {
            echo "Tidak ada baris yang ditemukan untuk kriteria yang diberikan.";
        }
    } else {
        echo "Error in executing SQL query: " . mysqli_error($connect);
    }
}
?>
