<?php
	header('location:home.php?page=auth');
?>