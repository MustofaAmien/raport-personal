<?php
function UploadUser($fupload_name){
  $vdir_upload = "img_user/";
  $vfile_upload = $vdir_upload . $fupload_name;
  $imageType = $_FILES["fupload"]["type"];

  move_uploaded_file($_FILES["fupload"]["tmp_name"], $vfile_upload);

  switch($imageType) {
    case "image/gif":
      $im_src = imagecreatefromgif($vfile_upload);
      break;
    case "image/jpeg":
    case "image/jpg":
      $im_src = imagecreatefromjpeg($vfile_upload);
      break;
    case "image/png":
      $im_src = imagecreatefrompng($vfile_upload);
      break;
  }

  $src_width = imagesx($im_src);
  $src_height = imagesy($im_src);

  if($src_width >= 2000){
    $dst_width = 2000;
  } else {
    $dst_width = $src_width;
  }
  $dst_height = ($dst_width / $src_width) * $src_height;

  $im = imagecreatetruecolor($dst_width, $dst_height);
  imagecopyresampled($im, $im_src, 0, 0, 0, 0, $dst_width, $dst_height, $src_width, $src_height);

  switch($imageType) {
    case "image/gif":
      imagegif($im, $vdir_upload . $fupload_name);
      break;
    case "image/jpeg":
    case "image/jpg":
      imagejpeg($im, $vdir_upload . $fupload_name);
      break;
    case "image/png":
      imagepng($im, $vdir_upload . $fupload_name);
      break;
  }

  $dst_width2 = 110;
  $dst_height2 = ($dst_width2 / $src_width) * $src_height;

  $im2 = imagecreatetruecolor($dst_width2, $dst_height2);
  imagecopyresampled($im2, $im_src, 0, 0, 0, 0, $dst_width2, $dst_height2, $src_width, $src_height);

  switch($imageType) {
    case "image/gif":
      imagegif($im2, $vdir_upload . "small_" . $fupload_name);
      break;
    case "image/jpeg":
    case "image/jpg":
      imagejpeg($im2, $vdir_upload . "small_" . $fupload_name);
      break;
    case "image/png":
      imagepng($im2, $vdir_upload . "small_" . $fupload_name);
      break;
  }

  imagedestroy($im_src);
  imagedestroy($im);
  imagedestroy($im2);
}
?>
